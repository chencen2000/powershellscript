Start-Process C:\Windows\System32\notepad.exe
exit 0